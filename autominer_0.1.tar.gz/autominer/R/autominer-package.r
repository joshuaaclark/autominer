#' autominer.
#'
#' @name autominer
#' @docType package
NULL
